package one.digitalinnovation.enums;

public enum  TipoVeiculo {
    TERRESTRE, // tipo do enum
    AQUATICO,
    AEREO
}