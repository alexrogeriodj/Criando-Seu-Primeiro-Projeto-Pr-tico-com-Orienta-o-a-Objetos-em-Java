package one.digitalinnovation.statics;

public class Cachorro {
    //public String zoologia = "Quadrupede"; // uma instância
    public static String zoologia = "Quadrupede"; // todas instâncias

    public static String late() {
        return "Au!Au!";
    }
}