package one.digitalinnovation.tipos.tipagem;

public class TipagemEstatica {
    public static void main(String[] args) {
		// string em um tipo integer, inteiro. Aprensentará ERRO ao compilar
		Integer numero = "123456789";
    }
}