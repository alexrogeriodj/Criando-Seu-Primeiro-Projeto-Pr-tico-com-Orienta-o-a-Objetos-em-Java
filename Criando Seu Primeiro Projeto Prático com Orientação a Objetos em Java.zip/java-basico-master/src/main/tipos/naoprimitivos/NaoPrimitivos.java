package one.digitalinnovation.tipos.naoprimitivos;

public class NaoPrimitivos {
    public static void main(String[] args) {	
        String texto = "Meu texto para apresentação"; // sequência de caracteres
        Void v; //Tipo válido
        Object o = new Object(); // Object é o objeto principal do Java
        Number numero = Integer.valueOf(100);
        numero.toString();
    }
}