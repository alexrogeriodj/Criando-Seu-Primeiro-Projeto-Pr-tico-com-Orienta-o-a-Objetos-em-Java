package one.digitalinnovation.classes;

// classes com o primeiro nome sempre em maiúsculo
public class Programa {
	
	// principal método para execução de um programa em Java "public static void main"
	public static void main(String[] args) {
		
		// printando na tela a mensagem desejada
		System.out.println("Hello Word!");
	}
}