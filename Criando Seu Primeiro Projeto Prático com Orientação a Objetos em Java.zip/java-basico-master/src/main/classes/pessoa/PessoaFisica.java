package one.digitalinnovation.classes.pessoa;

// PessoaFisica extends Pessoa
public class PessoaFisica extends Pessoa {
    public PessoaFisica(final Integer idade, final Float peso) {
        super(idade, peso);
    }
}