package aulas.oo.part02.construtores.exemplo001;

public class Pessoa {
    private String nome;
		
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}